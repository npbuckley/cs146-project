function toggleGroceryBagsPrice() {
  var cap = document.getElementById("caption1");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $26.99';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleLanternsPrice() {
  var cap = document.getElementById("caption2");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $28.00';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleLightbulbsPrice() {
  var cap = document.getElementById("caption3");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $12.78/four lightbulbs';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleWalletPrice() {
  var cap = document.getElementById("caption4");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $25.00';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleHandbagPrice() {
  var cap = document.getElementById("caption5");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $70.00 - $80.00';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function togglePhoneCasePrice() {
  var cap = document.getElementById("caption6");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $49.95 - $54.95';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleCoffeeCupPrice() {
  var cap = document.getElementById("caption7");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $19.95';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleFlashlightPrice() {
  var cap = document.getElementById("caption8");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $63.65';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleCrockeryPrice() {
  var cap = document.getElementById("caption9");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $8.06 - $364.86';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}

function toggleGardenPotsPrice() {
  var cap = document.getElementById("caption10");
  if (cap.innerHTML == "Price:") {
    cap.innerHTML = 'Price: Currently $4.89/pot';
  } 
  else {
    cap.innerHTML = "Price:";
  }
}
